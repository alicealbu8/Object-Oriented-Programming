#pragma once
#include "Repository.h"
#include "Domain.h"
#include <stack>
#include <iostream>


using namespace std;

typedef enum {

	ADD, REMOVE, EDIT

}ActionType;

class Action {
private:

	Chocolate value;
	ActionType type;

public:

	Action();
	Action(Chocolate value, ActionType type);
	Chocolate getValue() { return value; }
	ActionType getType() { return type; }
	void setValue(Chocolate value) { this->value = value; }
	void setType(ActionType type) { this->type = type; }


	friend std::ostream& operator<<(std::ostream& s, Action a);
};

class Controller {
private:

	ChocolateRepo chocolate_controller;

public:
	Controller();
	void addChocolate_controller(Chocolate* choc);
	void removeChocolate_controller();
	void editChocolate_controller(string id, float new_price, string new_id, string new_type, ChocolateRepo c);
	//std::vector<Chocolate*> filter_controller(FilterPrice chocolate_controller);
	void UNDO(stack<Action>& Undo, stack<Action>& Redo);
	void REDO(stack<Action>& Undo, stack<Action>& Redo);

	std::vector<Chocolate*>  getController() { return chocolate_controller.GetChocolate(); };

	friend std::ostream& operator<<(std::ostream& s, Controller chocolate_controller);
};

